# OS Lab 3 // May, Taylor - ID: 101516431

## Introduction

> This is based on the requirements set in the lab3 pdf

> This program emulates a Memory Management system with various algorithms

> There was nothing stating the use of STL was not allowed for this lab, so vectors are used

## Features

> This program features four different algorithms

> First In First Out(FIFO)

> Least Recently Used(LRU)

> Most Frequently Used(MFU)

> Optimal(OPT)

> All data is output to a data file which is the 3rd argument